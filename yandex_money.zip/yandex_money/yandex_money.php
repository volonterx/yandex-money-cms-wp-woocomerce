<?php
/**
	Plugin Name: yandexmoney_wp_woocommerce
	Plugin URI: https://github.com/yandex-money/yandexmoney_wp_woocommerce
	Description: Online shop with Yandex.Money support.
	Version: 1.2.0
	Author: Yandex.Money
	Author URI: http://money.yandex.ru
 */

include_once 'yandex/yandex.php';
include_once 'bank/bank.php';
include_once 'terminal/terminal.php';
include_once 'webmoney/webmoney.php';
include_once 'alfabank/alfabank.php';
include_once 'masterpass/masterpass.php';
include_once 'mobile/mobile.php';
include_once 'psbank/psbank.php';
include_once 'sberbank/sberbank.php';
/*
add_filter( 'woocommerce_general_settings', 'add_order_ym_shopPassword' );
function add_order_ym_shopPassword( $settings ) {
  $updated_settings = array();
  foreach ( $settings as $section ) {
    if ( isset( $section['id'] ) && 'general_options' == $section['id'] &&
       isset( $section['type'] ) && 'sectionend' == $section['type'] ) {
      $updated_settings[] = array(
        'name'     => __('Яндекс.Деньги shopPassword','yandex_money'),
        'id'       => 'ym_shopPassword',
        'type'     => 'text',
        'css'      => 'min-width:300px;',
        'std'      => '',  // WC < 2.0
        'default'  => '',  // WC >= 2.0
        'desc'     => __( '<br/>Необходим для корректной работы paymentAvisoURL и checkURL. shopPassword устанавливается при регистрации магазина в системе Яндекс.Деньги', 'yandex_money' ),
      );
	  
		$pages = get_pages(); 
		$p_arr = array();
		foreach ( $pages as $page ) 
			$p_arr[$page->ID] = $page->post_title;
		
    }
    $updated_settings[] = $section;
  }
  return $updated_settings;
}
*/
function register_my_setting() {
	register_setting( 'woocommerce-yamoney', 'ym_Scid'); 
	register_setting( 'woocommerce-yamoney', 'ym_ShopID'); 
	register_setting( 'woocommerce-yamoney', 'ym_shopPassword'); 
	register_setting( 'woocommerce-yamoney', 'ym_Demo'); 
	error_log("register_my_setting");
} 
add_action('admin_menu', 'register_yandexMoney_submenu_page');
add_action('update_option_ym_ShopID', 'after_update_setting');
function register_yandexMoney_submenu_page() {

	add_submenu_page( 'woocommerce', 'Яндекс.Деньги Настройка', 'Яндекс.Деньги Настройка', 'manage_options', 'yandex_money_menu', 'yandexMoney_submenu_page_callback' );
	add_action('admin_init', 'register_my_setting' );
}

function yandexMoney_submenu_page_callback() {
?>
<div class="wrap">
<h2>Настройки Яндекс.Деньги</h2>
<p>Любое использование Вами программы означает полное и безоговорочное принятие Вами условий лицензионного договора, размещенного по адресу https://money.yandex.ru/doc.xml?id=527132 (далее – «Лицензионный договор»). Если Вы не принимаете условия Лицензионного договора в полном объёме, Вы не имеете права использовать программу в каких-либо целях.</p>
<form method="post" action="options.php">
<?php 
wp_nonce_field('update-options'); 
settings_fields( 'woocommerce-yamoney' );
do_settings_sections( 'woocommerce-yamoney' );
?>

<table class="form-table">

<tr valign="top">
<th scope="row">paymentAvisoUrl and checkUrl<br/><span style="line-height: 1;font-weight: normal;font-style: italic;font-size: 12px;">Генерируются автоматически для Вашего сайта<span></th>
<td><code><?php
 echo 'https://'.$_SERVER['HTTP_HOST']. '/?yandex_money=check'; 
 ?></code></td>
</tr>

<tr valign="top">
<th scope="row">Демо режим<br/><span style="line-height: 1;font-weight: normal;font-style: italic;font-size: 12px;">Включить демо режим для тестирования<span></th>
<td><input type="checkbox" name="ym_Demo" <?php echo get_option('ym_Demo')=='on'?'checked="checked"':''; ?>" /></td>
</tr>

<tr valign="top">
<th scope="row">Scid<br/><span style="line-height: 1;font-weight: normal;font-style: italic;font-size: 12px;">Номер витрины магазина ЦПП<span></th>
<td><input type="text" name="ym_Scid" value="<?php echo get_option('ym_Scid'); ?>" /></td>
</tr>
 
<tr valign="top">
<th scope="row">ShopID<br/><span style="line-height: 1;font-weight: normal;font-style: italic;font-size: 12px;">Номер магазина ЦПП<span></th>
<td><input type="text" name="ym_ShopID" value="<?php echo get_option('ym_ShopID'); ?>" /></td>
</tr>

<tr valign="top">
<th scope="row">shopPassword<br/><span style="line-height: 1;font-weight: normal;font-style: italic;font-size: 12px;">Устанавливается при регистрации магазина в системе Яндекс.Деньги<span></th>
<td><input type="text" name="ym_shopPassword" value="<?php echo get_option('ym_shopPassword'); ?>" /></td>
</tr>

</table>

<input type="hidden" name="action" value="update" />
<input type="hidden" name="page_options" value="ym_Scid,ym_ShopID,ym_shopPassword,ym_Demo" />

<p class="submit">
<input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
</p>

</form>
</div>
<?php
}

add_action('parse_request', 'YMcheckPayment');

function after_update_setting($one){
		new yamoney_statistics();
}

function YMcheckPayment()
{
	global $wpdb;
	// if ($_REQUEST['yandex_money'] == 'hash') {
		// echo md5('');
	// }
	if ($_REQUEST['yandex_money'] == 'check') {
		$hash = md5($_POST['action'].';'.$_POST['orderSumAmount'].';'.$_POST['orderSumCurrencyPaycash'].';'.
					$_POST['orderSumBankPaycash'].';'.$_POST['shopId'].';'.$_POST['invoiceId'].';'.
					$_POST['customerNumber'].';'.get_option('ym_shopPassword'));
		header('Content-Type: application/xml');
		if (strtolower($hash) != strtolower($_POST['md5']) and (isset($_POST['md5']))) { // !=
			$code = 1;
			echo '<?xml version="1.0" encoding="UTF-8"?><checkOrderResponse performedDatetime="'. $_POST['requestDatetime'] .'" code="'.$code.'"'. ' invoiceId="'. $_POST['invoiceId'] .'" shopId="'. get_option('ym_ShopID') .'" message="bad md5"/>';
		} else {
			$order = $wpdb->get_row('SELECT * FROM '.$wpdb->prefix.'posts WHERE ID = '.(int)$_POST['customerNumber']);
			$order_summ = get_post_meta($order->ID,'_order_total',true);
			if (!$order) {
				$code = 200;
				$answer = '<?xml version="1.0" encoding="UTF-8"?><checkOrderResponse performedDatetime="'. $_POST['requestDatetime'] .'" code="'.$code.'"'. ' invoiceId="'. $_POST['invoiceId'] .'" shopId="'. get_option('ym_ShopID') .'" message="wrong customerNumber"/>';
			} elseif ($order_summ != $_POST['orderSumAmount']) { // !=
				$code = 100;
				$answer = '<?xml version="1.0" encoding="UTF-8"?><checkOrderResponse performedDatetime="'. $_POST['requestDatetime'] .'" code="'.$code.'"'. ' invoiceId="'. $_POST['invoiceId'] .'" shopId="'. get_option('ym_ShopID') .'" message="wrong orderSumAmount"/>';
			} else {
				$code = 0;
				if ($_POST['action'] == 'paymentAviso') {
					$order_w = new WC_Order( $order->ID );
					$order_w->update_status('processing', __( 'Awaiting BACS payment', 'woocommerce' ));
					$order_w->reduce_order_stock();
					$answer = '<?xml version="1.0" encoding="UTF-8"?><paymentAvisoResponse performedDatetime="'.date('c').'" code="'.$code.'" invoiceId="'.$_POST['invoiceId'].'" shopId="'.get_option('ym_ShopID').'" />';
				}
				else{
					$answer = '<?xml version="1.0" encoding="UTF-8"?><checkOrderResponse performedDatetime="'.date('c').'" code="'.$code.'" invoiceId="'.$_POST['invoiceId'].'" shopId="'.get_option('ym_ShopID').'" />';
				}
			}
		}
		
		die($answer);
		
	}
}
class yamoney_statistics {
	public function __construct(){
		$this->send();
	}

	private function send()
	{
		global $wp_version;
		$array = array(
			'url' => get_option('siteurl'),
			'cms' => 'wordpress-woo',
			'version' => $wp_version,
			'ver_mod' => '1.2.0',
			'yacms' => false,
			'email' => get_option('admin_email'),
			'shopid' => get_option('ym_ShopID'),
			'settings' => array(
				'kassa' => true
			)
		);

		$key_crypt = gethostbyname($_SERVER['HTTP_HOST']);
		$array_crypt = $this->crypt_encrypt($array, $key_crypt);

		$url = 'https://statcms.yamoney.ru/';
		$curlOpt = array(
			CURLOPT_HEADER => false,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_SSL_VERIFYHOST => false,
			CURLINFO_HEADER_OUT => true,
			CURLOPT_POST => true,
		);

		$curlOpt[CURLOPT_HTTPHEADER] = array('Content-Type: application/x-www-form-urlencoded');
		$curlOpt[CURLOPT_POSTFIELDS] = http_build_query(array('data' => $array_crypt));

		$curl = curl_init($url);
		curl_setopt_array($curl, $curlOpt);
		$rbody = curl_exec($curl);
		$errno = curl_errno($curl);
		$error = curl_error($curl);
		$rcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		curl_close($curl);
	}
	
	private function crypt_encrypt($data, $key)
	{
		$key = hash('sha256', $key, true);
		$data = serialize($data);
		$init_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_CBC);
		$init_vect = mcrypt_create_iv($init_size, MCRYPT_RAND);
		$str = $this->randomString(strlen($key)).$init_vect.mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $key, $data, MCRYPT_MODE_CBC, $init_vect);
		return base64_encode($str);
	}

	private function randomString($len)
	{
		$str = '';
		$pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$pool_len = strlen($pool);
		for ($i = 0; $i < $len; $i++) {
			$str .= substr($pool, mt_rand(0, $pool_len - 1), 1);
		}
		return $str;
	}
}